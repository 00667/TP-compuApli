#!/bin/bash

# Validar argumentos
if [[ "$1" == "-help" ]]; then
	echo "Uso: backup_full.sh <origen> <destino>"
	echo "ejemplo: backup_full.sh /var/log /backup_dir"
	exit 0
fi

# Validar que haya 2 argumentos
if [[ $# -ne 2 ]]; then
	echo "Error: se requieren 2 argumentos: origen y destino"
	exit 1
fi

# Variables
ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE_BKP=$(basename $ORIGEN)_bkp_$FECHA.tar.gz

# Validar que los directorios existen
if [[ ! -d "$DESTINO" ]]; then
	echo "Error: El destino '$DESTINO' no existe."
	exit 1
fi

# Crear el backup
tar -czf $DESTINO/$NOMBRE_BKP $ORIGEN

echo "Backup completado: $DESTINO/$NOMBRE_BKP"
